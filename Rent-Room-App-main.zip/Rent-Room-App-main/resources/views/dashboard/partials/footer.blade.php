 <!-- Start Footer -->
 <footer class="footer d-flex justify-content-center">
    <div class="container">
      &copy; Copyright <strong><span>SiManuk</span></strong
      >. All Rights Reserved
    </div>
  </footer>
  <!-- End Footer -->