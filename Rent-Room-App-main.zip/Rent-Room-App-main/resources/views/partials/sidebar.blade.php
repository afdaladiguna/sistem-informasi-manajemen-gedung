<div class=" col-md-2 col-6 p-0 sidebar">
    <ul class="nav flex-column ">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard/admin">Daftar Admin</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashboard/users">Daftar User</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashboard/rooms">Daftar Ruangan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashboard/rents">Daftar Peminjaman</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/dashboard/temporaryRents">Daftar Peminjaman Sementara</a>
      </li>
    </ul>
</div>